# Model Card — Atlas Rocket-1.0

## Resumen

Atlas Rocket-1.0 es un modelo de lenguaje autorregresivo (Transformer decoder,
estilo GPT) entrenado desde cero para continuar fragmentos de código Python.
Es un proyecto educativo/demostrativo, no una herramienta de producción.

## Arquitectura

| | |
|---|---|
| Tipo | Transformer decoder causal (estilo GPT-2 / nanoGPT) |
| Parámetros | 861,312 |
| Capas | 3 |
| Cabezas de atención | 4 |
| Dimensión de embedding | 128 |
| Ventana de contexto | 80 tokens (~215 caracteres en promedio) |
| Vocabulario | 2,000 tokens (BPE a nivel de byte, estilo GPT-2) |
| Tying de pesos | embedding de entrada = proyección de salida |
| Framework de entrenamiento | PyTorch 2.13 (CPU) |
| Inferencia | JavaScript puro, sin dependencias, en el navegador |

## Datos de entrenamiento

~7.5M caracteres de código fuente Python real, obtenido instalando paquetes de
código abierto vía `pip` y concatenando sus archivos `.py`:

`click`, `flask`, `jinja2`, `markdown`, `tabulate`, `requests`, `rich`, `pygments`

El texto se filtró a caracteres ASCII antes de tokenizar. El tokenizador BPE
(2,000 tokens) se entrenó sobre este mismo corpus con la librería `tokenizers`
de Hugging Face (una herramienta de preprocesamiento de texto, no un modelo de IA).

No se incluyó ningún dato conversacional, de instrucciones, ni pares
pregunta-respuesta — por eso Atlas **completa/continúa texto**, no responde
preguntas ni sigue instrucciones como un chatbot convencional.

## Entrenamiento

- 4,500 iteraciones, batch size 24, longitud de secuencia 80 tokens
- Optimizador AdamW, learning rate 3e-4, weight decay 0.01
- ~13 minutos de cómputo en 1 núcleo de CPU
- Loss final: entrenamiento 2.67 · validación 3.38 (entropía cruzada, nats/token)
  → perplejidad ≈ 14.4 sobre un vocabulario de 2,000 tokens

## Uso previsto

- Demostración educativa de cómo funciona un LLM por dentro (tokenización,
  atención, entrenamiento, muestreo) de punta a punta, con cada pieza
  implementada y ejecutada en vivo.
- Curiosidad / experimentación personal.
- Punto de partida para quien quiera entrenar su propia versión más grande
  o con más datos.

## Limitaciones conocidas (importante)

- **No genera código correcto ni ejecutable de forma confiable.** Aprende la
  *forma* del código (indentación, docstrings, nombres de clase/método
  plausibles) pero no su semántica ni su corrección sintáctica garantizada.
- **Tiende a repetirse** en generaciones largas (ej. `self.md.md.md.md...`),
  un problema común en modelos de este tamaño con muestreo simple.
- **Contexto muy corto** (80 tokens) comparado con modelos de producción
  (decenas o cientos de miles de tokens).
- **No sigue instrucciones ni responde preguntas** — solo continúa texto,
  porque no fue entrenado con datos de ese tipo.
- **Sesgado hacia los patrones del corpus de entrenamiento** (p. ej. genera
  con frecuencia estructuras parecidas a las de Pygments, la librería más
  grande del corpus).

## Los niveles de esfuerzo (Bajo / Medio / Alto / Max)

Implementados como muestreo *mejor-de-N*: cada nivel genera 1, 2, 4 u 8
continuaciones independientes y se queda con la de mayor log-verosimilitud
promedio bajo el propio modelo (es decir, la que el modelo mismo considera
más probable). Es una técnica real de cómputo en tiempo de inferencia, no
una animación cosmética — por eso "Max" tarda más: literalmente está
generando y comparando 8 veces más texto.

| Nivel | Variantes | Tokens máx. | Temperatura | Tiempo aprox. |
|---|---|---|---|---|
| Bajo | 1 | 70 | 0.90 | ~0.3s |
| Medio | 2 | 130 | 0.75 | ~1s |
| Alto | 4 | 190 | 0.65 | ~4s |
| Max | 8 | 260 | 0.55 | ~10-15s |

## Comparación honesta

Atlas Rocket-1.0 tiene 861K parámetros. Los modelos de código de producción
(Claude, Copilot, CodeLlama, etc.) tienen entre decenas de miles y millones
de veces más parámetros, entrenados con billones de tokens en clústeres de
GPUs durante semanas o meses. La diferencia de capacidad es proporcional a
esa diferencia de escala — no es una cuestión de mejor o peor ingeniería,
sino de recursos de cómputo, varios órdenes de magnitud distintos.
