# Atlas Rocket-1.0

Un modelo de lenguaje pequeño, entrenado **desde cero** (sin usar ninguna IA existente),
especializado en continuar código. Corre 100% offline, en un solo archivo HTML,
sin backend ni conexión a internet.

## Uso

Abre `atlas-rocket-1.0.html` en cualquier navegador moderno (Chrome, Firefox, Edge, Safari).
Eso es todo — no necesita instalación, servidor, ni internet. Puedes moverlo, compartirlo
por USB, o subirlo a cualquier hosting estático (GitHub Pages, Netlify, etc.) y funcionará igual.

Escríbele el inicio de una línea de código en Python y déjalo continuar:

```
def calculate_total(items):
class Config:
import
```

Ajusta el **nivel de esfuerzo** (Bajo/Medio/Alto/Max) para controlar cuánto "piensa"
antes de responder — genera 1, 2, 4 u 8 variantes candidatas y se queda con la más
probable según el propio modelo. Más esfuerzo = más cómputo real = más espera.

## Qué es (y qué no es)

**Es:** un Transformer decoder real (estilo GPT), de ~861,000 parámetros, entrenado
durante ~50 minutos sobre una sola CPU con código fuente de librerías Python de
código abierto. Todo el pipeline —arquitectura, entrenamiento, tokenizador BPE,
e inferencia— fue construido para este proyecto, sin usar Claude, GPT, ni ningún
otro modelo preentrenado como base.

**No es:** una herramienta de código de producción. Genera texto con *forma* de
Python (indentación, docstrings, clases, listas) pero rara vez código correcto o
ejecutable. Compáralo con los primeros experimentos educativos de "char-RNN"/mini-GPT,
no con Copilot o Claude. Ver `MODEL_CARD.md` para el detalle técnico completo.

## Contenido de esta carpeta

```
atlas-rocket-1.0.html   ← el modelo, la app, todo en un solo archivo (ábrelo y ya)
README.md               ← este archivo
MODEL_CARD.md           ← ficha técnica: arquitectura, datos, entrenamiento, limitaciones
source/                 ← todo el código fuente que lo construyó, por si quieres
                           entrenar tu propia versión o entender cómo funciona por dentro
  model.py                → arquitectura del Transformer (PyTorch)
  train_tokenizer.py      → entrena el tokenizador BPE sobre el corpus
  prepare_bpe_data.py     → codifica el corpus de texto a tokens
  train_bpe.py            → bucle de entrenamiento (con soporte para reanudar)
  export.py               → exporta los pesos entrenados a JSON/base64 para el navegador
  atlas_engine.js          → motor de inferencia del Transformer, en JS puro
  bpe_tokenizer.js         → tokenizador BPE reimplementado en JS puro
  atlas_template.html      → plantilla de la interfaz (sin pesos embebidos)
  build.py                 → ensambla plantilla + motor + pesos en el .html final
```

## Reentrenar / mejorar el modelo

Si quieres entrenar tu propia versión (más datos, más iteraciones, otro lenguaje
de programación, etc.), necesitas Python 3.10+ y:

```bash
pip install torch tokenizers numpy
```

Luego, en orden:

```bash
python3 train_tokenizer.py      # entrena el tokenizador BPE (requiere corpus_ascii.txt)
python3 prepare_bpe_data.py     # codifica el corpus a tokens
python3 train_bpe.py            # entrena el modelo (guarda checkpoints automáticamente)
python3 export.py               # exporta los pesos entrenados
python3 build.py                # genera el .html final autocontenido
```

No se incluye el corpus de entrenamiento en esta carpeta (código fuente de librerías
como Flask, Click, Jinja2, Pygments, etc.) — se generó instalando esos paquetes con
`pip` y concatenando sus archivos `.py`. El script para regenerarlo es sencillo:
instala los paquetes que quieras con `pip install --target=corpus_env <paquetes>`
y concatena los `.py` resultantes en un solo `.txt`.

---

Construido en una conversación con Claude (Anthropic), con la arquitectura,
entrenamiento e inferencia genuinamente entrenados/ejecutados en el momento —
no es una fachada sobre otro modelo.
