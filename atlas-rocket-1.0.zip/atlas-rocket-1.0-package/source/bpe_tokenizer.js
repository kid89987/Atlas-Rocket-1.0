// Tokenizador BPE a nivel de byte (estilo GPT-2), escrito a mano.
// Reproduce exactamente el algoritmo usado para entrenar el tokenizador en Python:
// 1) pre-segmentación con la regex estándar de GPT-2
// 2) mapeo byte -> caracter imprimible (bytes_to_unicode)
// 3) fusiones BPE en orden de prioridad (merges)

function bytesToUnicode() {
  const bs = [];
  for (let i = '!'.charCodeAt(0); i <= '~'.charCodeAt(0); i++) bs.push(i);
  for (let i = 0xa1; i <= 0xac; i++) bs.push(i);
  for (let i = 0xae; i <= 0xff; i++) bs.push(i);
  const cs = bs.slice();
  let n = 0;
  for (let b = 0; b < 256; b++) {
    if (!bs.includes(b)) {
      bs.push(b);
      cs.push(256 + n);
      n += 1;
    }
  }
  const byteToChar = {};
  const charToByte = {};
  for (let i = 0; i < bs.length; i++) {
    const ch = String.fromCodePoint(cs[i]);
    byteToChar[bs[i]] = ch;
    charToByte[ch] = bs[i];
  }
  return { byteToChar, charToByte };
}

const GPT2_SPLIT_PATTERN = /'s|'t|'re|'ve|'m|'ll|'d| ?\p{L}+| ?\p{N}+| ?[^\s\p{L}\p{N}]+|\s+(?!\S)|\s+/gu;

class BpeTokenizer {
  constructor(bpeData) {
    this.vocab = bpeData.vocab; // token_string -> id
    this.idToToken = bpeData.id_to_token; // id -> token_string
    const { byteToChar, charToByte } = bytesToUnicode();
    this.byteToChar = byteToChar;
    this.charToByte = charToByte;

    this.mergeRank = new Map();
    bpeData.merges.forEach((pair, idx) => {
      this.mergeRank.set(pair[0] + '\u0001' + pair[1], idx);
    });
  }

  _bpeMergeChunk(chars) {
    let symbols = chars.slice();
    while (symbols.length > 1) {
      let bestRank = Infinity;
      let bestIdx = -1;
      for (let i = 0; i < symbols.length - 1; i++) {
        const key = symbols[i] + '\u0001' + symbols[i + 1];
        const rank = this.mergeRank.get(key);
        if (rank !== undefined && rank < bestRank) {
          bestRank = rank;
          bestIdx = i;
        }
      }
      if (bestIdx === -1) break;
      const merged = symbols[bestIdx] + symbols[bestIdx + 1];
      symbols = symbols.slice(0, bestIdx).concat([merged], symbols.slice(bestIdx + 2));
    }
    return symbols;
  }

  encode(text) {
    const ids = [];
    const chunks = text.match(GPT2_SPLIT_PATTERN) || [];
    const encoder = new TextEncoder();
    for (const chunk of chunks) {
      const bytes = encoder.encode(chunk);
      const chars = [];
      for (const b of bytes) chars.push(this.byteToChar[b]);
      const merged = this._bpeMergeChunk(chars);
      for (const sym of merged) {
        const id = this.vocab[sym];
        if (id !== undefined) ids.push(id);
        // símbolos fuera de vocabulario (no deberían ocurrir con texto ASCII normal) se omiten
      }
    }
    return ids;
  }

  decode(ids) {
    let charStr = '';
    for (const id of ids) {
      const tok = this.idToToken[id];
      if (tok !== undefined) charStr += tok;
    }
    const bytes = [];
    for (const ch of charStr) {
      const b = this.charToByte[ch];
      if (b !== undefined) bytes.push(b);
    }
    const decoder = new TextDecoder('utf-8');
    return decoder.decode(new Uint8Array(bytes));
  }
}

if (typeof module !== 'undefined') module.exports = { BpeTokenizer, bytesToUnicode, GPT2_SPLIT_PATTERN };
