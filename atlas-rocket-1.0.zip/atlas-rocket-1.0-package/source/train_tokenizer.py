from tokenizers import Tokenizer, models, pre_tokenizers, decoders, trainers

VOCAB_SIZE = 2000

tokenizer = Tokenizer(models.BPE())
tokenizer.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
tokenizer.decoder = decoders.ByteLevel()

trainer = trainers.BpeTrainer(
    vocab_size=VOCAB_SIZE,
    min_frequency=2,
    special_tokens=[],
    show_progress=True,
    initial_alphabet=pre_tokenizers.ByteLevel.alphabet(),
)

tokenizer.train(['corpus_ascii.txt'], trainer)
tokenizer.save('bpe_tokenizer.json')

vocab = tokenizer.get_vocab()
print('vocab size real:', len(vocab))

test = "def calculate_total(items):\n    return sum(x.price for x in items)"
enc = tokenizer.encode(test)
print('tokens:', len(enc.ids))
print(enc.tokens[:20])
dec = tokenizer.decode(enc.ids)
print('decodificado == original?', dec == test)
print(repr(dec))
