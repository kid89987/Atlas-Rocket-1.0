import json
import numpy as np
from tokenizers import Tokenizer

tok = Tokenizer.from_file('bpe_tokenizer.json')

with open('corpus_ascii.txt', 'r') as f:
    text = f.read()

print('codificando corpus completo...')
enc = tok.encode(text)
ids = np.array(enc.ids, dtype=np.uint16)
print('tokens totales:', len(ids), '  (compresión vs chars:', len(text) / len(ids), 'x)')

n = len(ids)
train_ids = ids[: int(n * 0.95)]
val_ids = ids[int(n * 0.95):]

train_ids.tofile('train_bpe.bin')
val_ids.tofile('val_bpe.bin')

vocab = tok.get_vocab()  # token_string -> id
print('vocab_size:', len(vocab))

with open('vocab_bpe.json', 'w') as f:
    json.dump({'vocab_size': len(vocab)}, f)

print('train tokens:', len(train_ids), ' val tokens:', len(val_ids))
